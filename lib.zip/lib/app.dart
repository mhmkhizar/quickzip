// import 'dart:io';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:hooks_riverpod/hooks_riverpod.dart';
// import 'package:quickzip/core/providers/connectivity_provider.dart';
// import 'package:quickzip/core/theme/app_theme.dart';
// import 'package:quickzip/features/home/presentation/home_screen.dart';

// class QuickZipApp extends HookConsumerWidget {
//   const QuickZipApp({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final isConnected = ref.watch(isConnectedProvider);

//     // Check if the platform is iOS or Android
//     if (Platform.isIOS) {
//       // Cupertino style for iOS
//       return CupertinoApp(
//         title: 'QuickZip',
//         theme: AppTheme.cupertinoDarkTheme,
//         home: const HomeScreen(),
//       );
//     } else {
//       // Material style for Android
//       return MaterialApp(
//         title: 'QuickZip',
//         theme: AppTheme.darkTheme,
//         home: const HomeScreen(),
//       );
//     }
//   }
// }
