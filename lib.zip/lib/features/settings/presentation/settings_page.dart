import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Feedback'),
            leading: const Icon(Icons.feedback),
            onTap: _openStorePage,
          ),
          ListTile(
            title: const Text('Share with friends'),
            leading: const Icon(Icons.share),
            onTap: () {
              Share.share('Check out QuickZip!');
            },
          ),
          ListTile(
            title: const Text('Privacy Policy'),
            leading: const Icon(Icons.privacy_tip),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => const AlertDialog(
                  title: Text('Privacy Policy'),
                  content: Text('Your privacy policy content here...'),
                ),
              );
            },
          ),
          const ListTile(
            title: Text('App Version'),
            leading: Icon(Icons.info),
            subtitle: Text('1.0.0'),
          ),
        ],
      ),
    );
  }

  Future<void> _openStorePage() async {
    final uri = Uri.parse(
      Platform.isAndroid
          ? 'market://details?id=com.yourcompany.quickzip'
          : 'https://apps.apple.com/app/idYOUR_APP_ID',
    );

    try {
      await launchUrl(uri);
    } catch (e) {
      debugPrint('Error opening store page: $e');
    }
  }
}
