import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';

class SplashContainer extends StatefulWidget {
  const SplashContainer({super.key});

  @override
  State<SplashContainer> createState() => SplashContainerState();
}

class SplashContainerState extends State<SplashContainer> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/logo/app_logo.png',
            height: 150,
            width: 150,
          ),
          // Padding(
          //   padding: const EdgeInsets.all(8.0),
          //   child: Text(
          //     "QuickZip",
          //     style: GoogleFonts.inter(
          //       color: Platform.isIOS ? CupertinoColors.black : Colors.black,
          //       fontWeight: FontWeight.bold,
          //       fontSize: 24,
          //     ),
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(
                Platform.isIOS ? CupertinoColors.systemRed : Colors.red,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
