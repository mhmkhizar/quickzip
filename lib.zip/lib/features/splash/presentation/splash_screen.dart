import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'dart:io';
import '../../../core/providers/connectivity_provider.dart';
import '../../home/presentation/home_screen.dart';
import '../widget/splash_widget.dart';
import 'no_internet_screen.dart';

class SplashScreen extends HookConsumerWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isConnected = ref.watch(connectivityProvider);
    debugPrint('Connectivity Status: $isConnected');
    WidgetsBinding.instance.addPostFrameCallback(
      (_) {
        Future.delayed(
          const Duration(seconds: 2),
          () {
            if (context.mounted) {
              if (isConnected) {
                debugPrint('Navigating to HomeScreen');
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const HomeScreen(),
                  ),
                );
              } else {
                debugPrint('Navigating to NoInternetScreen');
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const NoInternetScreen(),
                  ),
                );
              }
            }
          },
        );
      },
    );
    return Platform.isIOS
        ? const CupertinoPageScaffold(
            backgroundColor: Color(0xffD1D1D1),
            child: SplashContainer(),
          )
        : const Scaffold(
            backgroundColor: Color(0xffD1D1D1),
            body: SplashContainer(),
          );
  }
}
