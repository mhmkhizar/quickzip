import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quickzip/core/providers/zip_state_provider.dart';
import 'package:quickzip/features/extracted/widgets/extracted_file_tile.dart';

class ExtractedPage extends ConsumerWidget {
  const ExtractedPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(zipStateProvider);

    if (state.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state.error != null) {
      return Center(child: Text('Error: ${state.error}'));
    }

    if (state.extractedFiles.isEmpty) {
      return const Center(child: Text('No extracted files found'));
    }

    return ListView.builder(
      itemCount: state.extractedFiles.length,
      itemBuilder: (context, index) {
        final file = state.extractedFiles[index];
        return ExtractedFileTile(file: file);
      },
    );
  }
}