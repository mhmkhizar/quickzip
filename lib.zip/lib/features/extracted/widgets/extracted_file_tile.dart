import 'package:flutter/material.dart';
import 'package:quickzip/core/models/zip_file.dart';
import 'package:url_launcher/url_launcher.dart';

class ExtractedFileTile extends StatelessWidget {
  final ZipFile file;

  const ExtractedFileTile({
    super.key,
    required this.file,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(file.name),
      subtitle: Text(file.dateAdded.toString()),
      leading: const Icon(Icons.folder_open),
      onTap: () => _openFile(context),
      onLongPress: () => _handleLongPress(context),
    );
  }

  Future<void> _openFile(BuildContext context) async {
    try {
      final uri = Uri.file(file.path);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        throw 'Could not open file';
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening file: $e')),
      );
    }
  }

  void _handleLongPress(BuildContext context) {
    // TODO: Implement delete functionality
  }
}