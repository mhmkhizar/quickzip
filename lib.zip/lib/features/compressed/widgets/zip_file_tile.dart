import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quickzip/core/models/zip_file.dart';
import 'package:quickzip/core/providers/zip_state_provider.dart';
import 'package:quickzip/core/providers/ad_state_provider.dart';

class ZipFileTile extends ConsumerWidget {
  final ZipFile file;

  const ZipFileTile({
    super.key,
    required this.file,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListTile(
      title: Text(file.name),
      subtitle: Text(file.dateAdded.toString()),
      leading: const Icon(Icons.folder_zip),
      onTap: () => _handleTap(context, ref),
      onLongPress: () => _handleLongPress(context, ref),
    );
  }

  Future<void> _handleTap(BuildContext context, WidgetRef ref) async {
    if (file.requiresRewardedAd) {
      final shouldWatch = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Watch Ad'),
          content: const Text(
              'You have to watch an ad to extract this file. Do you wish to continue?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Watch'),
            ),
          ],
        ),
      );

      if (shouldWatch != true) return;

      // Show rewarded ad
      final adState = ref.read(adStateProvider);
      if (adState.rewardedAd == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Ad not available. Please try again later.')),
        );
        return;
      }

      adState.rewardedAd!.show(
        onUserEarnedReward: (_, reward) {
          _extractFile(context, ref);
        },
      );
    } else {
      _extractFile(context, ref);
    }
  }

  Future<void> _extractFile(BuildContext context, WidgetRef ref) async {
    if (file.isPasswordProtected) {
      final password = await _showPasswordDialog(context);
      if (password != null) {
        await ref
            .read(zipStateProvider.notifier)
            .extractZipFile(file, password: password);
      }
    } else {
      await ref.read(zipStateProvider.notifier).extractZipFile(file);
    }
  }

  Future<String?> _showPasswordDialog(BuildContext context) {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Enter Password'),
        content: TextField(
          controller: controller,
          obscureText: true,
          decoration: const InputDecoration(
            hintText: 'Password',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Extract'),
          ),
        ],
      ),
    );
  }

  void _handleLongPress(BuildContext context, WidgetRef ref) {
    // TODO: Implement delete functionality
  }
}
