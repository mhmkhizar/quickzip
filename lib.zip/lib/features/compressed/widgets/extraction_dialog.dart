import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:quickzip/core/providers/ad_state_provider.dart';
import '../../../core/services/ad_service.dart';

class ExtractionDialog extends HookConsumerWidget {
  final bool requiresAd;
  final Function onExtract;

  const ExtractionDialog({
    super.key,
    required this.requiresAd,
    required this.onExtract,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final adState = ref.watch(adStateProvider);
    final isLoading = useState(false);
    final inProcessBanner = useState<BannerAd?>(null);

    useEffect(() {
      if (requiresAd) {
        inProcessBanner.value = BannerAd(
          adUnitId: AdService.inProcessBannerAdUnitId,
          size: const AdSize(width: 300, height: 250),
          request: const AdRequest(),
          listener: BannerAdListener(
            onAdLoaded: (_) {},
            onAdFailedToLoad: (ad, error) {
              ad.dispose();
              inProcessBanner.value = null;
            },
          ),
        )..load();
      }
      return () => inProcessBanner.value?.dispose();
    }, []);

    Future<void> handleExtraction() async {
      try {
        isLoading.value = true;

        if (requiresAd) {
          if (adState.rewardedAd == null) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text('Ad not available. Please try again later.')),
            );
            return;
          }

          bool adCompleted = false;
          await adState.rewardedAd!.show(
            onUserEarnedReward: (_, __) {
              adCompleted = true;
            },
          );

          if (!adCompleted) return;
        }

        // Show in-process banner and loading for 4 seconds
        await Future.delayed(const Duration(seconds: 4));

        await onExtract();

        if (context.mounted) {
          Navigator.of(context).pop();
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error during extraction: $e')),
          );
        }
      } finally {
        isLoading.value = false;
      }
    }

    // Determine if platform is iOS or Android
    final isIOS = Theme.of(context).platform == TargetPlatform.iOS;

    // Material Dialog (Android) or Cupertino Dialog (iOS)
    if (isIOS) {
      return CupertinoAlertDialog(
        title: Text(requiresAd ? 'Watch Ad to Extract' : 'Extract File'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isLoading.value) ...[
              if (inProcessBanner.value != null)
                SizedBox(
                  width: 300,
                  height: 250,
                  child: AdWidget(ad: inProcessBanner.value!),
                ),
              const SizedBox(height: 16),
              const CupertinoActivityIndicator(),
              const SizedBox(height: 8),
              const Text('Extracting...'),
            ] else
              Text(requiresAd
                  ? 'You have to watch an ad to extract this file. Do you wish to continue?'
                  : 'Do you want to extract this file?'),
          ],
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: isLoading.value ? null : () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          CupertinoDialogAction(
            onPressed: isLoading.value ? null : handleExtraction,
            child: Text(requiresAd ? 'Watch' : 'Extract'),
          ),
        ],
      );
    } else {
      return AlertDialog(
        title: Text(requiresAd ? 'Watch Ad to Extract' : 'Extract File'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isLoading.value) ...[
              if (inProcessBanner.value != null)
                SizedBox(
                  width: 300,
                  height: 250,
                  child: AdWidget(ad: inProcessBanner.value!),
                ),
              const SizedBox(height: 16),
              const LinearProgressIndicator(),
              const SizedBox(height: 8),
              const Text('Extracting...'),
            ] else
              Text(requiresAd
                  ? 'You have to watch an ad to extract this file. Do you wish to continue?'
                  : 'Do you want to extract this file?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: isLoading.value ? null : () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: isLoading.value ? null : handleExtraction,
            child: Text(requiresAd ? 'Watch' : 'Extract'),
          ),
        ],
      );
    }
  }
}
