import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quickzip/core/providers/zip_state_provider.dart';
import 'package:quickzip/features/compressed/widgets/zip_file_tile.dart';

class CompressedPage extends ConsumerWidget {
  const CompressedPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(zipStateProvider);

    if (state.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state.error != null) {
      return Center(child: Text('Error: ${state.error}'));
    }

    if (state.compressedFiles.isEmpty) {
      return const Center(child: Text('No compressed files found'));
    }

    return ListView.builder(
      itemCount: state.compressedFiles.length,
      itemBuilder: (context, index) {
        final file = state.compressedFiles[index];
        return ZipFileTile(file: file);
      },
    );
  }
}