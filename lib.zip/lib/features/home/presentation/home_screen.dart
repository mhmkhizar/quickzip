import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:quickzip/features/compressed/presentation/compressed_page.dart';
import 'package:quickzip/features/extracted/presentation/extracted_page.dart';
import 'package:quickzip/features/settings/presentation/settings_page.dart';
import 'package:quickzip/core/providers/ad_state_provider.dart';
import 'package:quickzip/core/providers/zip_state_provider.dart';
import '../../../core/providers/connectivity_provider.dart';
import '../../splash/presentation/no_internet_screen.dart';

class HomeScreen extends HookConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isConnected = ref.watch(connectivityProvider);
    if (!isConnected) {
      Future.delayed(const Duration(seconds: 1), () {
        Navigator.pushReplacement(
          // ignore: use_build_context_synchronously
          context,
          MaterialPageRoute(builder: (_) => const NoInternetScreen()),
        );
      });
    }
    final currentIndex = useState(0);
    const pages = [CompressedPage(), ExtractedPage()];

    // Initialize Ads
    useEffect(() {
      Future.microtask(() async {
        await ref.read(adStateProvider.notifier).initAds();
        ref.read(adStateProvider.notifier).loadBannerAd();
      });
      return null;
    }, []);

    Future<void> pickFile() async {
      try {
        final result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['zip'],
          allowMultiple: true,
        );

        if (result != null) {
          for (final file in result.files) {
            if (file.path != null) {
              await ref
                  .read(zipStateProvider.notifier)
                  .addCompressedFile(file.path!);
            }
          }
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error picking files: $e')),
          );
        }
      }
    }

    // iOS UI
    if (Platform.isIOS) {
      return CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          middle: const Text('QuickZip'),
          trailing: CupertinoButton(
            padding: EdgeInsets.zero,
            onPressed: () {
              Navigator.push(
                context,
                CupertinoPageRoute(builder: (context) => const SettingsPage()),
              );
            },
            child: const Icon(CupertinoIcons.settings),
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              CupertinoSegmentedControl<int>(
                children: const {
                  0: Text('Compressed'),
                  1: Text('Extracted'),
                },
                onValueChanged: (value) => currentIndex.value = value,
                groupValue: currentIndex.value,
              ),
              Expanded(
                child: pages[currentIndex.value],
              ),
              Consumer(
                builder: (context, ref, child) {
                  final adState = ref.watch(adStateProvider);
                  if (adState.isBannerAdLoaded && adState.bannerAd != null) {
                    return SizedBox(
                      height: 50,
                      child: AdWidget(ad: adState.bannerAd!),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ],
          ),
        ),
      );
    }

    // Android UI
    return Scaffold(
      appBar: AppBar(
        title: const Text('QuickZip'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // TODO: Implement search
            },
          ),
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SettingsPage(),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: () => currentIndex.value = 0,
                  child: Text(
                    'Compressed',
                    style: TextStyle(
                      color:
                          currentIndex.value == 0 ? Colors.blue : Colors.grey,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: TextButton(
                  onPressed: () => currentIndex.value = 1,
                  child: Text(
                    'Extracted',
                    style: TextStyle(
                      color:
                          currentIndex.value == 1 ? Colors.blue : Colors.grey,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: pages[currentIndex.value],
          ),
          Consumer(
            builder: (context, ref, child) {
              final adState = ref.watch(adStateProvider);
              if (adState.isBannerAdLoaded && adState.bannerAd != null) {
                return SizedBox(
                  height: 50,
                  child: AdWidget(ad: adState.bannerAd!),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: pickFile,
        child: const Icon(Icons.add),
      ),
    );
  }
}
