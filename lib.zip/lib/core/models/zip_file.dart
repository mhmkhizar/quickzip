class ZipFile {
  final String name;
  final String path;
  final DateTime dateAdded;
  final bool isPasswordProtected;
  final bool isTomitoPlus;

  ZipFile({
    required this.name,
    required this.path,
    required this.dateAdded,
    this.isPasswordProtected = false,
    this.isTomitoPlus = false,
  });

  bool get requiresRewardedAd => isTomitoPlus;

  factory ZipFile.fromPath(String path) {
    final name = path.split('/').last;
    final isTomitoPlus = name.endsWith('Tomito+');
    
    return ZipFile(
      name: name,
      path: path,
      dateAdded: DateTime.now(),
      isTomitoPlus: isTomitoPlus,
    );
  }
}