import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppTheme {
  static const primaryRed = Color(0xFFE53935);
  static const darkBackground = Color(0xFF121212);
  static const darkSurface = Color(0xFF1E1E1E);
  static const darkError = Color(0xFFCF6679);

  // Material Dark Theme for Android
  static ThemeData get materialDarkTheme {
    return ThemeData.dark().copyWith(
      primaryColor: primaryRed,
      scaffoldBackgroundColor: darkBackground,
      appBarTheme: const AppBarTheme(
        backgroundColor: primaryRed,
        elevation: 0,
      ),
      colorScheme: const ColorScheme.dark(
        primary: primaryRed,
        surface: darkSurface,
        error: darkError,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primaryRed,
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primaryRed,
      ),
    );
  }

  // Cupertino Dark Theme for iOS
  static CupertinoThemeData get cupertinoDarkTheme {
    return const CupertinoThemeData(
      primaryColor: primaryRed,
      scaffoldBackgroundColor: darkBackground,
      textTheme: CupertinoTextThemeData(
        textStyle: TextStyle(
          color: CupertinoColors.white,
        ),
      ),
      barBackgroundColor: primaryRed,
    );
  }
}
