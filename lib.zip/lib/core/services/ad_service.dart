import 'dart:async';

import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdService {
  static const String bannerAdUnitId = 'ca-app-pub-3940256099942544/6300978111';
  static const String inProcessBannerAdUnitId =
      'ca-app-pub-3940256099942544/6300978111';
  static const String rewardedAdUnitId =
      'ca-app-pub-3940256099942544/5224354917';

  static Future<void> initialize() async {
    await MobileAds.instance.initialize();
  }

  static Future<RewardedAd?> loadRewardedAd() async {
    try {
      final completer = Completer<RewardedAd>();
      await RewardedAd.load(
        adUnitId: rewardedAdUnitId,
        request: const AdRequest(),
        rewardedAdLoadCallback: RewardedAdLoadCallback(
          onAdLoaded: (ad) => completer.complete(ad),
          // ignore: null_argument_to_non_null_type
          onAdFailedToLoad: (error) => completer.complete(null),
        ),
      );
      return await completer.future;
    } catch (e) {
      return null;
    }
  }
}
