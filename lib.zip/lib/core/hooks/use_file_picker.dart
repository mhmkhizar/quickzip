import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:file_picker/file_picker.dart';

Future<List<String>> useFilePicker({
  bool allowMultiple = true,
  List<String> allowedExtensions = const ['zip'],
}) async {
  final result = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: allowedExtensions,
    allowMultiple: allowMultiple,
  );

  if (result != null) {
    return result.files
        .where((file) => file.path != null)
        .map((file) => file.path!)
        .toList();
  }
  
  return [];
}