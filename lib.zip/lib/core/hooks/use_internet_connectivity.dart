import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

bool useInternetConnectivity() {
  final connectivity = useState<ConnectivityResult>(ConnectivityResult.none);

  useEffect(() {
    final subscription = Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) {
      connectivity.value = result;
    });

    return subscription.cancel;
  }, []);

  return connectivity.value != ConnectivityResult.none;
}