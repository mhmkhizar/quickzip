class PasswordGenerator {
  static bool isTomitoFile(String fileName) {
    return fileName.endsWith('Tomito+');
  }

  static String generatePassword(String fileName) {
    try {
      // Step 1: Remove special characters
      String cleanName = _removeSpecialCharacters(fileName).toLowerCase();

      // Step 2: Convert letters to numbers
      String numberString = _convertLettersToNumbers(cleanName);

      // Step 3: Take first 20 numbers
      String first20 = numberString.substring(0, 20);

      // Step 4: Increment by 1 (9 becomes 0)
      String incremented = _incrementNumbers(first20);

      // Step 5: Pair and mix
      String mixed = _pairAndMix(incremented);

      // Step 6: Reverse
      String reversed = mixed.split('').reversed.join();

      // Step 7: Increment again
      String incrementedAgain = _incrementNumbers(reversed);

      // Step 8: Pair and mix again
      String mixedAgain = _pairAndMix(incrementedAgain);

      // Step 9: Final reverse
      return mixedAgain.split('').reversed.join();
    } catch (e) {
      throw Exception('Failed to generate password: $e');
    }
  }

  static String _removeSpecialCharacters(String input) {
    return input.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '');
  }

  static String _convertLettersToNumbers(String input) {
    return input.split('').map((char) {
      if (RegExp(r'[0-9]').hasMatch(char)) {
        return char;
      }
      return (char.toLowerCase().codeUnitAt(0) - 96).toString();
    }).join();
  }

  static String _incrementNumbers(String input) {
    return input.split('').map((char) {
      int num = int.parse(char);
      return ((num + 1) % 10).toString();
    }).join();
  }

  static String _pairAndMix(String input) {
    List<String> chars = input.split('');
    List<String> result = [];
    int length = chars.length;
    
    for (int i = 0; i < length ~/ 2; i++) {
      result.add(chars[i]);
      result.add(chars[length - 1 - i]);
    }
    
    if (length % 2 != 0) {
      result.add(chars[length ~/ 2]);
    }
    
    return result.join();
  }
}