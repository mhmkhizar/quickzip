import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class FileUtils {
  static Future<String> getExtractedFilesPath() async {
    final appDir = await getApplicationDocumentsDirectory();
    return '${appDir.path}/QuickZip Extracted Files';
  }

  static Future<bool> requestStoragePermission() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  static Future<void> createDirectoryIfNotExists(String path) async {
    final directory = Directory(path);
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
  }

  static Future<List<FileSystemEntity>> listFiles(String path) async {
    final directory = Directory(path);
    return directory.list(recursive: true).where((entity) => entity is File).toList();
  }

  static Future<void> deleteFile(String path) async {
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
  }
}