import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'ad_provider.dart';

final adStateProvider = StateNotifierProvider<AdStateNotifier, AdState>((ref) {
  return AdStateNotifier();
});

class AdStateNotifier extends StateNotifier<AdState> {
  AdStateNotifier() : super(AdState());

  Future<void> initAds() async {
    await MobileAds.instance.initialize();
    state = state.copyWith(isInitialized: true);
    loadRewardedAd();
  }

  void loadBannerAd() {
    final BannerAd bannerAd = BannerAd(
      adUnitId: AdService.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          state = state.copyWith(isBannerAdLoaded: true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          state = state.copyWith(isBannerAdLoaded: false);
        },
      ),
    );

    bannerAd.load();
    state = state.copyWith(bannerAd: bannerAd);
  }

  void loadRewardedAd() {
    RewardedAd.load(
      adUnitId: AdService.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (RewardedAd ad) {
          state = state.copyWith(rewardedAd: ad);
        },
        onAdFailedToLoad: (LoadAdError error) {
          state = state.copyWith(rewardedAd: null);
          // Retry loading
          loadRewardedAd();
        },
      ),
    );
  }

  @override
  void dispose() {
    state.bannerAd?.dispose();
    state.rewardedAd?.dispose();
    super.dispose();
  }
}

class AdState {
  final bool isInitialized;
  final bool isBannerAdLoaded;
  final BannerAd? bannerAd;
  final RewardedAd? rewardedAd;

  AdState({
    this.isInitialized = false,
    this.isBannerAdLoaded = false,
    this.bannerAd,
    this.rewardedAd,
  });

  AdState copyWith({
    bool? isInitialized,
    bool? isBannerAdLoaded,
    BannerAd? bannerAd,
    RewardedAd? rewardedAd,
  }) {
    return AdState(
      isInitialized: isInitialized ?? this.isInitialized,
      isBannerAdLoaded: isBannerAdLoaded ?? this.isBannerAdLoaded,
      bannerAd: bannerAd ?? this.bannerAd,
      rewardedAd: rewardedAd ?? this.rewardedAd,
    );
  }
}
