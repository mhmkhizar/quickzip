import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quickzip/core/models/zip_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';

final zipStateProvider = StateNotifierProvider<ZipStateNotifier, ZipState>((ref) {
  return ZipStateNotifier();
});

class ZipStateNotifier extends StateNotifier<ZipState> {
  ZipStateNotifier() : super(ZipState()) {
    _initializeDirectory();
  }

  Future<void> _initializeDirectory() async {
    try {
      final status = await Permission.storage.request();
      if (!status.isGranted) {
        state = state.copyWith(
          error: 'Storage permission is required',
        );
        return;
      }

      final appDir = await getApplicationDocumentsDirectory();
      final extractedDir = Directory('${appDir.path}/QuickZip Extracted Files');
      if (!await extractedDir.exists()) {
        await extractedDir.create(recursive: true);
      }

      await loadZipFiles();
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to initialize directory: $e',
      );
    }
  }

  Future<void> loadZipFiles() async {
    state = state.copyWith(isLoading: true);
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final extractedDir = Directory('${appDir.path}/QuickZip Extracted Files');
      
      final extractedFiles = await extractedDir
          .list(recursive: true)
          .where((entity) => entity is File)
          .map((entity) => ZipFile.fromPath(entity.path))
          .toList();

      state = state.copyWith(
        extractedFiles: extractedFiles,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to load files: $e',
        isLoading: false,
      );
    }
  }

  Future<void> addCompressedFile(String path) async {
    try {
      final file = ZipFile.fromPath(path);
      final updatedFiles = [...state.compressedFiles, file];
      state = state.copyWith(
        compressedFiles: updatedFiles,
      );
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to add compressed file: $e',
      );
    }
  }

  Future<void> extractZipFile(ZipFile file, {String? password}) async {
    state = state.copyWith(isExtracting: true);
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final extractPath = '${appDir.path}/QuickZip Extracted Files/${file.name}';
      
      // Create extraction directory
      final extractDir = Directory(extractPath);
      if (!await extractDir.exists()) {
        await extractDir.create(recursive: true);
      }

      // TODO: Implement actual extraction logic using the archive package
      // This is where you would add the 4-second delay for ads
      await Future.delayed(const Duration(seconds: 4));

      // After extraction, reload the files
      await loadZipFiles();
      
      state = state.copyWith(isExtracting: false);
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to extract file: $e',
        isExtracting: false,
      );
    }
  }

  Future<void> deleteCompressedFile(ZipFile file) async {
    try {
      final fileToDelete = File(file.path);
      if (await fileToDelete.exists()) {
        await fileToDelete.delete();
      }
      
      final updatedFiles = state.compressedFiles
          .where((f) => f.path != file.path)
          .toList();
      
      state = state.copyWith(
        compressedFiles: updatedFiles,
      );
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to delete file: $e',
      );
    }
  }

  Future<void> deleteExtractedFile(ZipFile file) async {
    try {
      final fileToDelete = File(file.path);
      if (await fileToDelete.exists()) {
        await fileToDelete.delete();
      }
      
      final updatedFiles = state.extractedFiles
          .where((f) => f.path != file.path)
          .toList();
      
      state = state.copyWith(
        extractedFiles: updatedFiles,
      );
    } catch (e) {
      state = state.copyWith(
        error: 'Failed to delete file: $e',
      );
    }
  }
}

class ZipState {
  final bool isLoading;
  final bool isExtracting;
  final List<ZipFile> compressedFiles;
  final List<ZipFile> extractedFiles;
  final String? error;

  ZipState({
    this.isLoading = false,
    this.isExtracting = false,
    this.compressedFiles = const [],
    this.extractedFiles = const [],
    this.error,
  });

  ZipState copyWith({
    bool? isLoading,
    bool? isExtracting,
    List<ZipFile>? compressedFiles,
    List<ZipFile>? extractedFiles,
    String? error,
  }) {
    return ZipState(
      isLoading: isLoading ?? this.isLoading,
      isExtracting: isExtracting ?? this.isExtracting,
      compressedFiles: compressedFiles ?? this.compressedFiles,
      extractedFiles: extractedFiles ?? this.extractedFiles,
      error: error,
    );
  }
}